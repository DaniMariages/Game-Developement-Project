# Jumping Man

## Description

Juego de plataformas inspirado en super mario.

## Key Features

 - F1: Ver Colliders
 - F5: Guardar
 - F6: Cargar
 - F7: Ver Pathfinding
 - F10: God mode
 - UP: Mover camara hacia arriba
 - DOWN: Mover camara hacia abajo
 - LEFT: Mover camara hacia la izquierda
 - RIGHT: Mover camara hacia la derecha
 
## Controls

 - A: Moverse hacia la derecha
 - D: Moverse hacia la izquierda
 -SPACE: Saltar

## Developers

 - Toni Romanos
 - Dani Mariages

## License

This project is licensed under an unmodified MIT license, which is an OSI-certified license that allows static linking with closed source software. Check [LICENSE](LICENSE) for further details.

{AdditionalLicenses}
