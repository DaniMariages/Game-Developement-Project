<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="Overworld" tilewidth="16" tileheight="16" tilecount="3200" columns="80">
 <image source="../../../../../../../Desktop/Overworld.png" width="1283" height="654"/>
</tileset>
