<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="tiles-3" tilewidth="32" tileheight="32" tilecount="110" columns="11">
 <image source="../../../../../../../Desktop/tiles-3.png" width="355" height="351"/>
</tileset>
